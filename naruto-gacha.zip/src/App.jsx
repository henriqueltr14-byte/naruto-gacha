import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Gift, Swords, BookOpen, Home, Users } from "lucide-react";

const characters = [
  { id: 1, name: "Naruto", rarity: "SSR", atk: 120, hp: 1000 },
  { id: 2, name: "Sasuke", rarity: "SSR", atk: 130, hp: 950 },
  { id: 3, name: "Sakura", rarity: "SR", atk: 80, hp: 1100 },
  { id: 4, name: "Kakashi", rarity: "SR", atk: 100, hp: 1000 },
  { id: 5, name: "Rock Lee", rarity: "R", atk: 70, hp: 900 },
  { id: 6, name: "Shikamaru", rarity: "R", atk: 65, hp: 950 },
  { id: 7, name: "Choji", rarity: "N", atk: 50, hp: 1000 },
  { id: 8, name: "Kiba", rarity: "N", atk: 55, hp: 900 },
];

const rates = { SSR: 0.05, SR: 0.15, R: 0.3, N: 0.5 };

export default function App() {
  const [inventory, setInventory] = useState([]);
  const [log, setLog] = useState([]);
  const [view, setView] = useState("home");
  const [dailyMissions, setDailyMissions] = useState({
    login: false,
    summon: false,
    battle: false,
  });

  useEffect(() => {
    const saved = localStorage.getItem("naruto-gacha-save");
    if (saved) {
      const data = JSON.parse(saved);
      setInventory(data.inventory || []);
      setDailyMissions(data.dailyMissions || dailyMissions);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(
      "naruto-gacha-save",
      JSON.stringify({ inventory, dailyMissions })
    );
  }, [inventory, dailyMissions]);

  function summon() {
    let rand = Math.random();
    let rarity = "N";
    if (rand < rates.SSR) rarity = "SSR";
    else if (rand < rates.SSR + rates.SR) rarity = "SR";
    else if (rand < rates.SSR + rates.SR + rates.R) rarity = "R";

    const pool = characters.filter((c) => c.rarity === rarity);
    const chosen = pool[Math.floor(Math.random() * pool.length)];
    setInventory([...inventory, chosen]);
    setDailyMissions({ ...dailyMissions, summon: true });
    setLog([`Você obteve ${chosen.name} (${chosen.rarity})!`, ...log]);
  }

  function battle() {
    if (inventory.length < 3) {
      alert("Você precisa de pelo menos 3 personagens!");
      return;
    }
    const team = inventory.slice(0, 3);
    const enemy = [
      { name: "Ninja Inimigo", atk: 60, hp: 800 },
      { name: "Ladrão da Névoa", atk: 70, hp: 850 },
      { name: "Rogue Ninja", atk: 80, hp: 900 },
    ];

    let myHP = team.reduce((acc, c) => acc + c.hp, 0);
    let enemyHP = enemy.reduce((acc, e) => acc + e.hp, 0);

    while (myHP > 0 && enemyHP > 0) {
      enemyHP -= team.reduce((acc, c) => acc + c.atk, 0);
      if (enemyHP <= 0) break;
      myHP -= enemy.reduce((acc, e) => acc + e.atk, 0);
    }

    if (myHP > 0) {
      setLog(["Você venceu a batalha!", ...log]);
      setDailyMissions({ ...dailyMissions, battle: true });
    } else {
      setLog(["Você foi derrotado!", ...log]);
    }
  }

  useEffect(() => {
    setDailyMissions((prev) => ({ ...prev, login: true }));
  }, []);

  function renderView() {
    if (view === "home") {
      return (
        <div className="p-4 text-center">
          <h1 className="text-2xl font-bold mb-4">Naruto Gacha</h1>
          <p>Escolha uma aba abaixo para jogar!</p>
        </div>
      );
    }

    if (view === "gacha") {
      return (
        <div className="p-4 text-center">
          <h2 className="text-xl font-bold mb-4">Summon</h2>
          <button
            onClick={summon}
            className="bg-orange-500 px-4 py-2 rounded-xl shadow-lg"
          >
            Invocar!
          </button>
          <div className="mt-4">
            {log.map((l, i) => (
              <p key={i}>{l}</p>
            ))}
          </div>
        </div>
      );
    }

    if (view === "battle") {
      return (
        <div className="p-4 text-center">
          <h2 className="text-xl font-bold mb-4">Batalha</h2>
          <button
            onClick={battle}
            className="bg-red-600 px-4 py-2 rounded-xl shadow-lg"
          >
            Lutar!
          </button>
          <div className="mt-4">
            {log.map((l, i) => (
              <p key={i}>{l}</p>
            ))}
          </div>
        </div>
      );
    }

    if (view === "missions") {
      return (
        <div className="p-4">
          <h2 className="text-xl font-bold mb-4">Missões Diárias</h2>
          <ul>
            <li>Login: {dailyMissions.login ? "✅" : "❌"}</li>
            <li>Invocar: {dailyMissions.summon ? "✅" : "❌"}</li>
            <li>Batalha: {dailyMissions.battle ? "✅" : "❌"}</li>
          </ul>
        </div>
      );
    }

    if (view === "gallery") {
      return (
        <div className="p-4">
          <h2 className="text-xl font-bold mb-4">Galeria</h2>
          <div className="grid grid-cols-2 gap-2">
            {inventory.map((c, i) => (
              <motion.div
                key={i}
                className="p-2 bg-gray-800 rounded-xl"
                whileHover={{ scale: 1.05 }}
              >
                <p className="font-bold">{c.name}</p>
                <p className="text-sm">{c.rarity}</p>
              </motion.div>
            ))}
          </div>
        </div>
      );
    }
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      <div className="flex-1">{renderView()}</div>
      <nav className="bg-gray-800 p-2 flex justify-around">
        <button onClick={() => setView("home")}>
          <Home />
        </button>
        <button onClick={() => setView("gacha")}>
          <Gift />
        </button>
        <button onClick={() => setView("battle")}>
          <Swords />
        </button>
        <button onClick={() => setView("missions")}>
          <BookOpen />
        </button>
        <button onClick={() => setView("gallery")}>
          <Users />
        </button>
      </nav>
    </div>
  );
}
